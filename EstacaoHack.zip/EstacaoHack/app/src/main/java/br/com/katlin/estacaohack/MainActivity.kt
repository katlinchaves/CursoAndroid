package br.com.katlin.estacaohack

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
//Método que utiliza do botão para mudar o texto da textView
        btnEntrar.setOnClickListener {

            //Pegando as informações das edits
            val usuario = edtUsuario.text.toString().trim()
            val senha = edtSenha.text.toString().trim()
            // .trim -> elimina os espaços ao pegar o conteúdo

            //txvResultado.text = senha//
            //(ou) txvResultado.text = "Bem-Vindo $usuario"//

            /*
            //Criando condição para mostrar logado caso tenha conteudo nas edit
            if(usuario.isNotEmpty()){
                // isEmpty (vazio) ou isNotEmpty (não vazio) -> verifica se o campo ta vazio ou não
                txvResultado.text = "Logado"
            }else{
                txvResultado.text = "Campo Vazio"
            }*/

            if(usuario.isNotEmpty()){
                if(senha.isNotEmpty()){

                    if(usuario == "admin" && senha == "123"){
                        txvResultado.text = "logado"
                    }else{
                        txvResultado.text = "senha ou usuario incorreto"
                    }

                }else{
                    txvResultado.text = "senha vazio"
                }

            }else{
                txvResultado.text = "usuario vazio"
            }

        }
    }
}
